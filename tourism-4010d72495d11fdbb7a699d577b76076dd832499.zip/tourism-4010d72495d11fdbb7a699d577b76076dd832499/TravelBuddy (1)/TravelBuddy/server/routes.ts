import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { 
  insertUserSchema, 
  insertBookingSchema,
  type User 
} from "@shared/schema";
import { ZodError } from "zod";

// Extend Request interface to include user property
declare global {
  namespace Express {
    interface Request {
      user?: {
        id: string;
        email: string;
      };
    }
  }
}

const JWT_SECRET = process.env.JWT_SECRET || "dev_wander_coders_tourism_jwt_secret_2024";

// Middleware to verify JWT token
const authenticateToken = (req: Request, res: Response, next: Function) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Access token required' });
  }

  jwt.verify(token, JWT_SECRET, (err: any, user: any) => {
    if (err) {
      return res.status(403).json({ error: 'Invalid token' });
    }
    req.user = user;
    next();
  });
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Authentication routes
  app.post('/api/auth/signup', async (req: Request, res: Response) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByEmail(userData.email);
      if (existingUser) {
        return res.status(400).json({ error: 'User already exists with this email' });
      }
      
      // Hash password
      const hashedPassword = await bcrypt.hash(userData.password, 10);
      
      // Create user
      const user = await storage.createUser({
        ...userData,
        password: hashedPassword
      });
      
      // Generate JWT token
      const token = jwt.sign(
        { id: user.id, email: user.email }, 
        JWT_SECRET, 
        { expiresIn: '24h' }
      );
      
      res.status(201).json({ 
        user: { id: user.id, name: user.name, email: user.email }, 
        token 
      });
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ error: 'Invalid input data', details: error.errors });
      }
      res.status(500).json({ error: 'Internal server error' });
    }
  });

  app.post('/api/auth/login', async (req: Request, res: Response) => {
    try {
      const { email, password } = req.body;
      
      if (!email || !password) {
        return res.status(400).json({ error: 'Email and password are required' });
      }
      
      // Find user
      const user = await storage.getUserByEmail(email);
      if (!user) {
        return res.status(401).json({ error: 'Invalid credentials' });
      }
      
      // Verify password
      const isValidPassword = await bcrypt.compare(password, user.password);
      if (!isValidPassword) {
        return res.status(401).json({ error: 'Invalid credentials' });
      }
      
      // Generate JWT token
      const token = jwt.sign(
        { id: user.id, email: user.email }, 
        JWT_SECRET, 
        { expiresIn: '24h' }
      );
      
      res.json({ 
        user: { id: user.id, name: user.name, email: user.email }, 
        token 
      });
    } catch (error) {
      res.status(500).json({ error: 'Internal server error' });
    }
  });

  // Destinations routes
  app.get('/api/destinations', async (req: Request, res: Response) => {
    try {
      const destinations = await storage.getDestinations();
      res.json(destinations);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch destinations' });
    }
  });

  app.get('/api/destinations/:id', async (req: Request, res: Response) => {
    try {
      const destination = await storage.getDestination(req.params.id);
      if (!destination) {
        return res.status(404).json({ error: 'Destination not found' });
      }
      res.json(destination);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch destination' });
    }
  });

  // Hotels routes
  app.get('/api/hotels', async (req: Request, res: Response) => {
    try {
      const destinationId = req.query.destinationId as string;
      const hotels = await storage.getHotels(destinationId);
      res.json(hotels);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch hotels' });
    }
  });

  app.get('/api/hotels/:id', async (req: Request, res: Response) => {
    try {
      const hotel = await storage.getHotel(req.params.id);
      if (!hotel) {
        return res.status(404).json({ error: 'Hotel not found' });
      }
      res.json(hotel);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch hotel' });
    }
  });

  // Bookings routes (protected)
  app.get('/api/bookings', authenticateToken, async (req: Request, res: Response) => {
    try {
      const userId = req.user?.id;
      const bookings = await storage.getBookings(userId);
      res.json(bookings);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch bookings' });
    }
  });

  app.post('/api/bookings', authenticateToken, async (req: Request, res: Response) => {
    try {
      const userId = req.user?.id;
      const bookingData = insertBookingSchema.parse({
        ...req.body,
        userId
      });
      
      const booking = await storage.createBooking(bookingData);
      res.status(201).json(booking);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ error: 'Invalid booking data', details: error.errors });
      }
      res.status(500).json({ error: 'Failed to create booking' });
    }
  });

  app.put('/api/bookings/:id', authenticateToken, async (req: Request, res: Response) => {
    try {
      const userId = req.user?.id;
      const bookingId = req.params.id;
      
      // Check if booking belongs to user
      const existingBooking = await storage.getBooking(bookingId);
      if (!existingBooking || existingBooking.userId !== userId) {
        return res.status(404).json({ error: 'Booking not found' });
      }
      
      const updatedBooking = await storage.updateBooking(bookingId, req.body);
      res.json(updatedBooking);
    } catch (error) {
      res.status(500).json({ error: 'Failed to update booking' });
    }
  });

  app.delete('/api/bookings/:id', authenticateToken, async (req: Request, res: Response) => {
    try {
      const userId = req.user?.id;
      const bookingId = req.params.id;
      
      // Check if booking belongs to user
      const existingBooking = await storage.getBooking(bookingId);
      if (!existingBooking || existingBooking.userId !== userId) {
        return res.status(404).json({ error: 'Booking not found' });
      }
      
      const deleted = await storage.deleteBooking(bookingId);
      if (deleted) {
        res.json({ message: 'Booking cancelled successfully' });
      } else {
        res.status(500).json({ error: 'Failed to cancel booking' });
      }
    } catch (error) {
      res.status(500).json({ error: 'Failed to cancel booking' });
    }
  });

  // Cost profiles routes
  app.get('/api/cost-profiles/:destinationId', async (req: Request, res: Response) => {
    try {
      const costProfiles = await storage.getCostProfiles(req.params.destinationId);
      res.json(costProfiles);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch cost profiles' });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
