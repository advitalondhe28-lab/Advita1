import { 
  type User, type InsertUser,
  type Destination, type InsertDestination,
  type Hotel, type InsertHotel,
  type Booking, type InsertBooking,
  type CostProfile, type InsertCostProfile
} from "@shared/schema";
import { randomUUID } from "crypto";
import destinationsData from "@shared/data/destinations.json";
import hotelsData from "@shared/data/hotels.json";
import costProfilesData from "@shared/data/costProfiles.json";

// modify the interface with any CRUD methods
// you might need

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Destination methods
  getDestinations(): Promise<Destination[]>;
  getDestination(id: string): Promise<Destination | undefined>;
  
  // Hotel methods
  getHotels(destinationId?: string): Promise<Hotel[]>;
  getHotel(id: string): Promise<Hotel | undefined>;
  
  // Booking methods
  getBookings(userId?: string): Promise<Booking[]>;
  getBooking(id: string): Promise<Booking | undefined>;
  createBooking(booking: InsertBooking): Promise<Booking>;
  updateBooking(id: string, updates: Partial<Booking>): Promise<Booking | undefined>;
  deleteBooking(id: string): Promise<boolean>;
  
  // Cost Profile methods
  getCostProfiles(destinationId: string): Promise<CostProfile[]>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private destinations: Map<string, Destination>;
  private hotels: Map<string, Hotel>;
  private bookings: Map<string, Booking>;
  private costProfiles: Map<string, CostProfile>;

  constructor() {
    this.users = new Map();
    this.destinations = new Map();
    this.hotels = new Map();
    this.bookings = new Map();
    this.costProfiles = new Map();
    this.seedData();
  }

  private seedData() {
    // Load destinations
    destinationsData.forEach(dest => {
      const id = this.generateId(dest.name);
      this.destinations.set(id, { ...dest, id });
    });
    
    // Load hotels
    hotelsData.forEach(hotel => {
      const id = this.generateId(hotel.name);
      const destinationId = this.getDestinationIdByName(hotel.destinationId);
      this.hotels.set(id, { ...hotel, id, destinationId });
    });
    
    // Load cost profiles
    costProfilesData.forEach(profile => {
      const id = randomUUID();
      const destinationId = this.getDestinationIdByName(profile.destinationId);
      this.costProfiles.set(id, { ...profile, id, destinationId });
    });
  }
  
  private generateId(name: string): string {
    return name.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '');
  }
  
  private getDestinationIdByName(nameOrId: string): string {
    // If it's already an ID format, return as is
    if (nameOrId.includes('-')) return nameOrId;
    
    // Convert name to ID format
    return this.generateId(nameOrId);
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id, createdAt: new Date() };
    this.users.set(id, user);
    return user;
  }
  
  // Destination methods
  async getDestinations(): Promise<Destination[]> {
    return Array.from(this.destinations.values());
  }
  
  async getDestination(id: string): Promise<Destination | undefined> {
    return this.destinations.get(id);
  }
  
  // Hotel methods
  async getHotels(destinationId?: string): Promise<Hotel[]> {
    const hotels = Array.from(this.hotels.values());
    if (destinationId) {
      return hotels.filter(hotel => hotel.destinationId === destinationId);
    }
    return hotels;
  }
  
  async getHotel(id: string): Promise<Hotel | undefined> {
    return this.hotels.get(id);
  }
  
  // Booking methods
  async getBookings(userId?: string): Promise<Booking[]> {
    const bookings = Array.from(this.bookings.values());
    if (userId) {
      return bookings.filter(booking => booking.userId === userId);
    }
    return bookings;
  }
  
  async getBooking(id: string): Promise<Booking | undefined> {
    return this.bookings.get(id);
  }
  
  async createBooking(insertBooking: InsertBooking): Promise<Booking> {
    const id = randomUUID();
    const booking: Booking = { 
      ...insertBooking, 
      id, 
      createdAt: new Date(),
      status: insertBooking.status || 'confirmed',
      totalAmount: insertBooking.totalAmount || null
    };
    this.bookings.set(id, booking);
    return booking;
  }
  
  async updateBooking(id: string, updates: Partial<Booking>): Promise<Booking | undefined> {
    const booking = this.bookings.get(id);
    if (!booking) return undefined;
    
    // Only allow updating specific fields for security
    const allowedUpdates: Partial<Booking> = {};
    
    if (updates.status !== undefined) allowedUpdates.status = updates.status;
    if (updates.checkIn !== undefined) allowedUpdates.checkIn = updates.checkIn;
    if (updates.checkOut !== undefined) allowedUpdates.checkOut = updates.checkOut;
    if (updates.guests !== undefined) allowedUpdates.guests = updates.guests;
    if (updates.totalAmount !== undefined) allowedUpdates.totalAmount = updates.totalAmount;
    
    const updatedBooking = { ...booking, ...allowedUpdates };
    this.bookings.set(id, updatedBooking);
    return updatedBooking;
  }
  
  async deleteBooking(id: string): Promise<boolean> {
    return this.bookings.delete(id);
  }
  
  // Cost Profile methods
  async getCostProfiles(destinationId: string): Promise<CostProfile[]> {
    return Array.from(this.costProfiles.values())
      .filter(profile => profile.destinationId === destinationId);
  }
}

export const storage = new MemStorage();
