import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/components/ui/theme-provider";
import { Header } from "@/components/header";
import Home from "@/pages/home";
import Destinations from "@/pages/destinations";
import Hotels from "@/pages/hotels";
import Budget from "@/pages/budget";
import Bookings from "@/pages/bookings";
import Login from "@/pages/login";
import Contact from "@/pages/contact";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/destinations" component={Destinations} />
      <Route path="/hotels" component={Hotels} />
      <Route path="/budget" component={Budget} />
      <Route path="/bookings" component={Bookings} />
      <Route path="/login" component={Login} />
      <Route path="/contact" component={Contact} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider defaultTheme="light" storageKey="tourism-ui-theme">
        <TooltipProvider>
          <div className="min-h-screen bg-background">
            <Switch>
              <Route path="/login">
                <Login />
              </Route>
              <Route>
                <Header />
                <main>
                  <Router />
                </main>
              </Route>
            </Switch>
          </div>
          <Toaster />
        </TooltipProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
