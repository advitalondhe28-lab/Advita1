import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { MapPin, Star, Wifi, Car, Coffee, Users } from "lucide-react"

interface HotelCardProps {
  id: string
  name: string
  image: string
  location: string
  rating: number
  reviewCount: number
  price: number
  originalPrice?: number
  amenities: string[]
  type: "hotel" | "restaurant"
  onBook?: (id: string) => void
}

export function HotelCard({
  id,
  name,
  image,
  location,
  rating,
  reviewCount,
  price,
  originalPrice,
  amenities,
  type,
  onBook
}: HotelCardProps) {
  const amenityIcons = {
    "WiFi": Wifi,
    "Parking": Car,
    "Restaurant": Coffee,
    "Family Rooms": Users
  }

  return (
    <Card className="hover-elevate group cursor-pointer overflow-hidden" data-testid={`card-${type}-${id}`}>
      <div className="relative">
        <img
          src={image}
          alt={name}
          className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
        />
        <Badge className="absolute top-2 left-2 bg-primary text-primary-foreground">
          {type === "hotel" ? "Hotel" : "Restaurant"}
        </Badge>
        <div className="absolute bottom-2 left-2 flex items-center space-x-1 bg-black/50 text-white px-2 py-1 rounded">
          <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
          <span className="text-sm font-medium">{rating}</span>
          <span className="text-sm">({reviewCount})</span>
        </div>
      </div>
      
      <CardHeader className="pb-2">
        <CardTitle className="line-clamp-1">{name}</CardTitle>
        <CardDescription className="flex items-center text-muted-foreground">
          <MapPin className="h-4 w-4 mr-1" />
          {location}
        </CardDescription>
      </CardHeader>
      
      <CardContent className="pt-0">
        <div className="flex items-center space-x-2 mb-3">
          {amenities.slice(0, 4).map((amenity) => {
            const Icon = amenityIcons[amenity as keyof typeof amenityIcons]
            return Icon ? (
              <div key={amenity} className="flex items-center space-x-1 text-xs text-muted-foreground">
                <Icon className="h-3 w-3" />
                <span className="hidden sm:inline">{amenity}</span>
              </div>
            ) : null
          })}
        </div>
        
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-2">
            <span className="text-xl font-bold text-primary">₹{price}</span>
            {originalPrice && (
              <span className="text-sm text-muted-foreground line-through">₹{originalPrice}</span>
            )}
            <span className="text-sm text-muted-foreground">
              {type === "hotel" ? "/night" : "/person"}
            </span>
          </div>
        </div>
        
        <Button 
          className="w-full" 
          onClick={() => onBook?.(id)}
          data-testid={`button-book-${id}`}
        >
          {type === "hotel" ? "Book Now" : "Reserve Table"}
        </Button>
      </CardContent>
    </Card>
  )
}