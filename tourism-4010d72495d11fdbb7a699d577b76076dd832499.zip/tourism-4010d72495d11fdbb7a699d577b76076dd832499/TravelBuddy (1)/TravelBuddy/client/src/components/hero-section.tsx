import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Search, MapPin } from "lucide-react"
import { useState } from "react"
// TODO: Remove mock functionality - these imports will be replaced with real data
import tajMahalImage from "@assets/generated_images/Taj_Mahal_golden_hour_tourism_d7872015.png"

export function HeroSection() {
  const [searchQuery, setSearchQuery] = useState("")

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    console.log("Hero search triggered for:", searchQuery)
    // TODO: Implement search functionality
  }

  return (
    <section className="relative h-[70vh] flex items-center justify-center overflow-hidden">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0">
        <img
          src={tajMahalImage}
          alt="Beautiful travel destination"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/60 via-black/40 to-black/60"></div>
      </div>
      
      {/* Content */}
      <div className="relative z-10 text-center max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
          Discover India's
          <span className="block text-chart-3"> Hidden Gems</span>
        </h1>
        
        <p className="text-lg md:text-xl text-white/90 mb-8 max-w-2xl mx-auto">
          Plan your perfect journey with our smart tourism platform. From ancient monuments to pristine beaches, explore India like never before.
        </p>
        
        {/* Search Bar */}
        <form onSubmit={handleSearch} className="max-w-2xl mx-auto">
          <div className="flex flex-col sm:flex-row gap-4 bg-white/10 backdrop-blur-md p-4 rounded-lg">
            <div className="relative flex-1">
              <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-white/70" />
              <Input
                type="search"
                placeholder="Where do you want to explore?"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 bg-white/20 border-white/30 text-white placeholder:text-white/70 focus:bg-white/30"
                data-testid="input-hero-search"
              />
            </div>
            <Button 
              type="submit" 
              variant="default"
              className="bg-chart-3 hover:bg-chart-3/90 text-white px-8"
              data-testid="button-hero-search"
            >
              <Search className="h-4 w-4 mr-2" />
              Search
            </Button>
          </div>
        </form>
        
        {/* Quick Actions */}
        <div className="flex flex-wrap justify-center gap-4 mt-8">
          <Button variant="outline" className="bg-white/10 border-white/30 text-white hover:bg-white/20">
            Popular Destinations
          </Button>
          <Button variant="outline" className="bg-white/10 border-white/30 text-white hover:bg-white/20">
            Budget Tours
          </Button>
          <Button variant="outline" className="bg-white/10 border-white/30 text-white hover:bg-white/20">
            Heritage Sites
          </Button>
        </div>
      </div>
    </section>
  )
}