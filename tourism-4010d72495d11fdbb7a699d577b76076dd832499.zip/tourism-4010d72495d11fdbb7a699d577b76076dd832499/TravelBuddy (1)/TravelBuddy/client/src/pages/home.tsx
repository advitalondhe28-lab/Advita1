import { DestinationCard } from "@/components/destination-card"
import { HeroSection } from "@/components/hero-section"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { MapPin, Users, Shield, Heart } from "lucide-react"
// TODO: Remove mock functionality - these imports will be replaced with real data
import tajMahalImage from "@assets/generated_images/Taj_Mahal_golden_hour_tourism_d7872015.png"
import keralaImage from "@assets/generated_images/Kerala_backwaters_travel_destination_eb004d1a.png"
import rajasthanImage from "@assets/generated_images/Rajasthan_palace_travel_destination_62582ba7.png"

export default function Home() {
  // TODO: Remove mock data - this will be replaced with real API data
  const featuredDestinations = [
    {
      id: "taj-mahal",
      name: "Taj Mahal",
      image: tajMahalImage,
      description: "A symbol of eternal love and one of the Seven Wonders of the World. Experience the breathtaking beauty of this marble masterpiece.",
      location: "Agra, Uttar Pradesh",
      bestTime: "Oct-Mar",
      rating: 4.8,
      reviewCount: 12450,
      featured: true
    },
    {
      id: "kerala-backwaters",
      name: "Kerala Backwaters",
      image: keralaImage,
      description: "Cruise through serene waterways surrounded by lush coconut palms and traditional villages. A perfect escape into nature.",
      location: "Alleppey, Kerala",
      bestTime: "Oct-Feb",
      rating: 4.6,
      reviewCount: 8920,
      featured: true
    },
    {
      id: "rajasthan-palaces",
      name: "Rajasthan Palaces",
      image: rajasthanImage,
      description: "Step into the royal heritage of India with magnificent palaces, vibrant culture, and tales of valor from ancient times.",
      location: "Jaipur, Rajasthan",
      bestTime: "Nov-Mar",
      rating: 4.7,
      reviewCount: 15300,
      featured: true
    }
  ]

  const handleExploreDestination = (id: string) => {
    console.log("Exploring destination:", id)
    // TODO: Navigate to destination detail page
  }

  return (
    <div className="min-h-screen">
      <HeroSection />
      
      {/* Featured Destinations Section */}
      <section className="py-12 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <h2 className="text-3xl font-bold text-foreground mb-4">
              Featured Destinations
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Discover India's most incredible destinations, handpicked for unforgettable experiences
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {featuredDestinations.map((destination) => (
              <DestinationCard
                key={destination.id}
                {...destination}
                onExplore={handleExploreDestination}
              />
            ))}
          </div>
          
          <div className="text-center mt-10">
            <Button size="lg" data-testid="button-view-all-destinations">
              View All Destinations
            </Button>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-12 bg-muted/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <h2 className="text-3xl font-bold text-foreground mb-4">
              Why Choose Smart Tourism?
            </h2>
            <p className="text-lg text-muted-foreground">
              Your perfect travel companion for exploring India
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="text-center hover-elevate">
              <CardHeader>
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <MapPin className="h-6 w-6 text-primary" />
                </div>
                <CardTitle>Expert Guidance</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Curated destinations and insider tips from local travel experts
                </CardDescription>
              </CardContent>
            </Card>
            
            <Card className="text-center hover-elevate">
              <CardHeader>
                <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Users className="h-6 w-6 text-accent" />
                </div>
                <CardTitle>Budget Planning</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Smart budget tools to plan your perfect trip within your means
                </CardDescription>
              </CardContent>
            </Card>
            
            <Card className="text-center hover-elevate">
              <CardHeader>
                <div className="w-12 h-12 bg-chart-3/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Shield className="h-6 w-6 text-chart-3" />
                </div>
                <CardTitle>Secure Booking</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Safe and secure hotel and restaurant reservations with instant confirmation
                </CardDescription>
              </CardContent>
            </Card>
            
            <Card className="text-center hover-elevate">
              <CardHeader>
                <div className="w-12 h-12 bg-chart-4/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Heart className="h-6 w-6 text-chart-4" />
                </div>
                <CardTitle>Personalized Experience</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Tailored recommendations based on your preferences and travel style
                </CardDescription>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </div>
  )
}