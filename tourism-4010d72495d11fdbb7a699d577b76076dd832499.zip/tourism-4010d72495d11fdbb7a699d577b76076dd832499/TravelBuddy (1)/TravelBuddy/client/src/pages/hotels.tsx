import { useState } from "react"
import { HotelCard } from "@/components/hotel-card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Search, Filter, MapPin } from "lucide-react"
// TODO: Remove mock functionality - these imports will be replaced with real data
import hotelImage from "@assets/generated_images/Luxury_hotel_room_accommodation_11a8e84a.png"
import restaurantImage from "@assets/generated_images/Indian_cuisine_restaurant_food_36165ad3.png"

export default function Hotels() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedLocation, setSelectedLocation] = useState("all")
  const [priceRange, setPriceRange] = useState("all")
  const [activeTab, setActiveTab] = useState("hotels")

  // TODO: Remove mock data - this will be replaced with real API data
  const hotels = [
    {
      id: "taj-hotel-agra",
      name: "The Oberoi Amarvilas",
      image: hotelImage,
      location: "Agra, Uttar Pradesh",
      rating: 4.8,
      reviewCount: 2340,
      price: 25000,
      originalPrice: 30000,
      amenities: ["WiFi", "Restaurant", "Parking", "Family Rooms"],
      type: "hotel" as const
    },
    {
      id: "backwater-resort",
      name: "Kumarakom Lake Resort",
      image: hotelImage,
      location: "Kumarakom, Kerala",
      rating: 4.6,
      reviewCount: 1890,
      price: 18000,
      amenities: ["WiFi", "Restaurant", "Parking", "Family Rooms"],
      type: "hotel" as const
    },
    {
      id: "palace-hotel-jaipur",
      name: "Taj Rambagh Palace",
      image: hotelImage,
      location: "Jaipur, Rajasthan",
      rating: 4.9,
      reviewCount: 3210,
      price: 35000,
      originalPrice: 40000,
      amenities: ["WiFi", "Restaurant", "Parking", "Family Rooms"],
      type: "hotel" as const
    },
    {
      id: "budget-hotel-delhi",
      name: "Hotel New Delhi Heights",
      image: hotelImage,
      location: "New Delhi",
      rating: 4.2,
      reviewCount: 890,
      price: 5000,
      amenities: ["WiFi", "Restaurant", "Parking"],
      type: "hotel" as const
    }
  ]

  const restaurants = [
    {
      id: "peshawri-agra",
      name: "Peshawri",
      image: restaurantImage,
      location: "Agra, Uttar Pradesh",
      rating: 4.7,
      reviewCount: 1560,
      price: 2500,
      amenities: ["WiFi", "Parking"],
      type: "restaurant" as const
    },
    {
      id: "kerala-cuisine",
      name: "Backwater Ripples",
      image: restaurantImage,
      location: "Alleppey, Kerala",
      rating: 4.5,
      reviewCount: 980,
      price: 1800,
      amenities: ["WiFi", "Parking"],
      type: "restaurant" as const
    },
    {
      id: "rajasthani-thali",
      name: "Chokhi Dhani",
      image: restaurantImage,
      location: "Jaipur, Rajasthan",
      rating: 4.6,
      reviewCount: 2340,
      price: 1500,
      amenities: ["WiFi", "Parking"],
      type: "restaurant" as const
    },
    {
      id: "street-food",
      name: "Paranthe Wali Gali",
      image: restaurantImage,
      location: "New Delhi",
      rating: 4.3,
      reviewCount: 1200,
      price: 800,
      amenities: ["WiFi"],
      type: "restaurant" as const
    }
  ]

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    console.log("Search triggered for:", searchQuery)
    // TODO: Implement search functionality
  }

  const handleBook = (id: string) => {
    console.log("Booking:", id)
    // TODO: Navigate to booking page
  }

  const currentData = activeTab === "hotels" ? hotels : restaurants
  
  const filteredData = currentData.filter(item => {
    const matchesSearch = searchQuery === "" || 
      item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.location.toLowerCase().includes(searchQuery.toLowerCase())
    
    const matchesLocation = selectedLocation === "all" || 
      item.location.toLowerCase().includes(selectedLocation.toLowerCase())
    
    const matchesPrice = priceRange === "all" || 
      (priceRange === "budget" && item.price <= 10000) ||
      (priceRange === "mid" && item.price > 10000 && item.price <= 25000) ||
      (priceRange === "luxury" && item.price > 25000)
    
    return matchesSearch && matchesLocation && matchesPrice
  })

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-primary text-primary-foreground py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            Hotels & Restaurants
          </h1>
          <p className="text-lg text-primary-foreground/90 max-w-2xl mx-auto">
            Find the perfect accommodation and dining experiences for your journey
          </p>
        </div>
      </div>

      {/* Tabs */}
      <div className="bg-card border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full max-w-md grid-cols-2">
              <TabsTrigger value="hotels" data-testid="tab-hotels">Hotels</TabsTrigger>
              <TabsTrigger value="restaurants" data-testid="tab-restaurants">Restaurants</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
      </div>

      {/* Filters and Search */}
      <div className="bg-card border-b py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row gap-4 items-center">
            {/* Search */}
            <form onSubmit={handleSearch} className="flex-1 max-w-md">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder={`Search ${activeTab}...`}
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                  data-testid={`input-${activeTab}-search`}
                />
              </div>
            </form>
            
            {/* Filters */}
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <Filter className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm font-medium">Filter by:</span>
              </div>
              
              <Select value={selectedLocation} onValueChange={setSelectedLocation}>
                <SelectTrigger className="w-[150px]" data-testid="select-location">
                  <SelectValue placeholder="Location" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Locations</SelectItem>
                  <SelectItem value="agra">Agra</SelectItem>
                  <SelectItem value="kerala">Kerala</SelectItem>
                  <SelectItem value="jaipur">Jaipur</SelectItem>
                  <SelectItem value="delhi">New Delhi</SelectItem>
                </SelectContent>
              </Select>
              
              <Select value={priceRange} onValueChange={setPriceRange}>
                <SelectTrigger className="w-[150px]" data-testid="select-price">
                  <SelectValue placeholder="Price Range" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Prices</SelectItem>
                  <SelectItem value="budget">Budget (Under ₹10k)</SelectItem>
                  <SelectItem value="mid">Mid-range (₹10k-25k)</SelectItem>
                  <SelectItem value="luxury">Luxury (Above ₹25k)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
      </div>

      {/* Results */}
      <div className="py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-foreground">
              {filteredData.length} {activeTab} found
            </h2>
            <div className="text-sm text-muted-foreground">
              Showing {filteredData.length} of {currentData.length} results
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredData.map((item) => (
              <HotelCard
                key={item.id}
                {...item}
                onBook={handleBook}
              />
            ))}
          </div>
          
          {filteredData.length === 0 && (
            <div className="text-center py-12">
              <p className="text-lg text-muted-foreground mb-4">
                No {activeTab} found matching your criteria
              </p>
              <Button 
                variant="outline" 
                onClick={() => {
                  setSearchQuery("")
                  setSelectedLocation("all")
                  setPriceRange("all")
                }}
                data-testid="button-clear-filters"
              >
                Clear Filters
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}