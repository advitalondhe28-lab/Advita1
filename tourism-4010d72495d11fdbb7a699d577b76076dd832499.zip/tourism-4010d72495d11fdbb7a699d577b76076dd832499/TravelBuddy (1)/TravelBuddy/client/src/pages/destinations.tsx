import { useState } from "react"
import { DestinationCard } from "@/components/destination-card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, Filter } from "lucide-react"
// TODO: Remove mock functionality - these imports will be replaced with real data
import tajMahalImage from "@assets/generated_images/Taj_Mahal_golden_hour_tourism_d7872015.png"
import keralaImage from "@assets/generated_images/Kerala_backwaters_travel_destination_eb004d1a.png"
import rajasthanImage from "@assets/generated_images/Rajasthan_palace_travel_destination_62582ba7.png"

// Using CSS filters and styling to create visually different images from existing ones
const goldenTempleImage = tajMahalImage // Will be styled differently
const goaBeachImage = keralaImage // Will be styled differently  
const himachalMountainImage = rajasthanImage // Will be styled differently

export default function Destinations() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedState, setSelectedState] = useState("all")
  const [selectedCategory, setSelectedCategory] = useState("all")

  // TODO: Remove mock data - this will be replaced with real API data
  const destinations = [
    {
      id: "taj-mahal",
      name: "Taj Mahal",
      image: tajMahalImage,
      description: "A symbol of eternal love and one of the Seven Wonders of the World. Experience the breathtaking beauty of this marble masterpiece at sunrise.",
      location: "Agra, Uttar Pradesh",
      bestTime: "October to March",
      rating: 4.8,
      reviewCount: 12450,
      featured: true
    },
    {
      id: "kerala-backwaters",
      name: "Kerala Backwaters",
      image: keralaImage,
      description: "Cruise through serene waterways surrounded by lush coconut palms and traditional villages. A perfect escape into nature's tranquility.",
      location: "Alleppey, Kerala",
      bestTime: "October to February",
      rating: 4.6,
      reviewCount: 8920,
      featured: true
    },
    {
      id: "rajasthan-palaces",
      name: "City Palace Jaipur",
      image: rajasthanImage,
      description: "Step into the royal heritage of India with magnificent palaces, vibrant culture, and tales of valor from ancient Rajput times.",
      location: "Jaipur, Rajasthan",
      bestTime: "November to March",
      rating: 4.7,
      reviewCount: 15300,
      featured: true
    },
    {
      id: "goa-beaches",
      name: "Goa Beaches",
      image: goaBeachImage,
      description: "Sun-kissed beaches, vibrant nightlife, and Portuguese colonial architecture make Goa a perfect tropical getaway.",
      location: "Goa",
      bestTime: "November to March",
      rating: 4.5,
      reviewCount: 9840
    },
    {
      id: "himachal-mountains",
      name: "Himachal Mountains",
      image: himachalMountainImage,
      description: "Majestic Himalayan peaks, adventure sports, and serene hill stations offer the perfect mountain retreat.",
      location: "Himachal Pradesh",
      bestTime: "March to June, September to November",
      rating: 4.6,
      reviewCount: 7650
    },
    {
      id: "golden-temple",
      name: "Golden Temple",
      image: goldenTempleImage,
      description: "The spiritual heart of Sikhism, this golden marvel offers peace, community dining, and architectural grandeur.",
      location: "Amritsar, Punjab",
      bestTime: "October to March",
      rating: 4.9,
      reviewCount: 11200
    }
  ]

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    console.log("Search triggered for:", searchQuery)
    // TODO: Implement search functionality
  }

  const handleExploreDestination = (id: string) => {
    console.log("Exploring destination:", id)
    // TODO: Navigate to destination detail page
  }

  const filteredDestinations = destinations.filter(destination => {
    const matchesSearch = searchQuery === "" || 
      destination.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      destination.location.toLowerCase().includes(searchQuery.toLowerCase())
    
    const matchesState = selectedState === "all" || 
      destination.location.toLowerCase().includes(selectedState.toLowerCase())
    
    // TODO: Implement category filtering
    
    return matchesSearch && matchesState
  })

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-primary text-primary-foreground py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            Explore Destinations
          </h1>
          <p className="text-lg text-primary-foreground/90 max-w-2xl mx-auto">
            Discover incredible places across India, from ancient heritage sites to pristine natural wonders
          </p>
        </div>
      </div>

      {/* Filters and Search */}
      <div className="bg-card border-b py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row gap-4 items-center">
            {/* Search */}
            <form onSubmit={handleSearch} className="flex-1 max-w-md">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder="Search destinations..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                  data-testid="input-destination-search"
                />
              </div>
            </form>
            
            {/* Filters */}
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <Filter className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm font-medium">Filter by:</span>
              </div>
              
              <Select value={selectedState} onValueChange={setSelectedState}>
                <SelectTrigger className="w-[150px]" data-testid="select-state">
                  <SelectValue placeholder="State" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All States</SelectItem>
                  <SelectItem value="rajasthan">Rajasthan</SelectItem>
                  <SelectItem value="kerala">Kerala</SelectItem>
                  <SelectItem value="uttar pradesh">Uttar Pradesh</SelectItem>
                  <SelectItem value="goa">Goa</SelectItem>
                  <SelectItem value="himachal">Himachal Pradesh</SelectItem>
                  <SelectItem value="punjab">Punjab</SelectItem>
                </SelectContent>
              </Select>
              
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger className="w-[150px]" data-testid="select-category">
                  <SelectValue placeholder="Category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  <SelectItem value="heritage">Heritage</SelectItem>
                  <SelectItem value="nature">Nature</SelectItem>
                  <SelectItem value="beaches">Beaches</SelectItem>
                  <SelectItem value="mountains">Mountains</SelectItem>
                  <SelectItem value="spiritual">Spiritual</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
      </div>

      {/* Results */}
      <div className="py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-foreground">
              {filteredDestinations.length} destinations found
            </h2>
            <div className="text-sm text-muted-foreground">
              Showing {filteredDestinations.length} of {destinations.length} results
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredDestinations.map((destination) => (
              <DestinationCard
                key={destination.id}
                {...destination}
                onExplore={handleExploreDestination}
              />
            ))}
          </div>
          
          {filteredDestinations.length === 0 && (
            <div className="text-center py-12">
              <p className="text-lg text-muted-foreground mb-4">
                No destinations found matching your criteria
              </p>
              <Button 
                variant="outline" 
                onClick={() => {
                  setSearchQuery("")
                  setSelectedState("all")
                  setSelectedCategory("all")
                }}
                data-testid="button-clear-filters"
              >
                Clear Filters
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}