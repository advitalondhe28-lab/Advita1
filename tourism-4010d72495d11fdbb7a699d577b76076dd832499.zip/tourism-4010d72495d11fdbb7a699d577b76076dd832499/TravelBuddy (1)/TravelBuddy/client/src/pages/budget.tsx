import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Separator } from "@/components/ui/separator"
import { Calculator, MapPin, Users, Calendar, IndianRupee, Plane, Hotel, Coffee, Car, Camera } from "lucide-react"

interface BudgetBreakdown {
  accommodation: number
  food: number
  transportation: number
  activities: number
  shopping: number
  miscellaneous: number
  total: number
}

export default function Budget() {
  const [days, setDays] = useState("")
  const [budget, setBudget] = useState("")
  const [destination, setDestination] = useState("")
  const [travelers, setTravelers] = useState("1")
  const [travelStyle, setTravelStyle] = useState("")
  const [breakdown, setBreakdown] = useState<BudgetBreakdown | null>(null)

  const calculateBudget = (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!days || !budget || !destination || !travelStyle) {
      console.log("Please fill all fields")
      return
    }

    const totalBudget = parseInt(budget)
    const numDays = parseInt(days)
    const numTravelers = parseInt(travelers)
    
    // TODO: Remove mock calculation - replace with real algorithm
    let accommodation = 0
    let food = 0
    let transportation = 0
    let activities = 0
    
    // Simple budget allocation based on travel style
    if (travelStyle === "budget") {
      accommodation = totalBudget * 0.25
      food = totalBudget * 0.25
      transportation = totalBudget * 0.20
      activities = totalBudget * 0.15
    } else if (travelStyle === "mid") {
      accommodation = totalBudget * 0.35
      food = totalBudget * 0.25
      transportation = totalBudget * 0.15
      activities = totalBudget * 0.15
    } else { // luxury
      accommodation = totalBudget * 0.45
      food = totalBudget * 0.25
      transportation = totalBudget * 0.10
      activities = totalBudget * 0.15
    }
    
    const shopping = totalBudget * 0.05
    const miscellaneous = totalBudget * 0.05
    
    setBreakdown({
      accommodation,
      food,
      transportation,
      activities,
      shopping,
      miscellaneous,
      total: totalBudget
    })
    
    console.log("Budget calculated for:", { days, budget, destination, travelers, travelStyle })
  }

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(amount)
  }

  const budgetCategories = [
    { key: 'accommodation', label: 'Accommodation', icon: Hotel, color: 'text-primary' },
    { key: 'food', label: 'Food & Dining', icon: Coffee, color: 'text-accent' },
    { key: 'transportation', label: 'Transportation', icon: Car, color: 'text-chart-3' },
    { key: 'activities', label: 'Activities & Tours', icon: Camera, color: 'text-chart-4' },
    { key: 'shopping', label: 'Shopping', icon: IndianRupee, color: 'text-chart-1' },
    { key: 'miscellaneous', label: 'Miscellaneous', icon: Plane, color: 'text-chart-2' }
  ]

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-primary text-primary-foreground py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            Budget Planner
          </h1>
          <p className="text-lg text-primary-foreground/90 max-w-2xl mx-auto">
            Plan your perfect trip within your budget with our smart cost calculator
          </p>
        </div>
      </div>

      <div className="py-8">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Budget Form */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calculator className="h-5 w-5" />
                  Trip Details
                </CardTitle>
                <CardDescription>
                  Enter your travel preferences to get a personalized budget breakdown
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={calculateBudget} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="destination">Destination</Label>
                      <Select value={destination} onValueChange={setDestination}>
                        <SelectTrigger data-testid="select-destination">
                          <SelectValue placeholder="Choose destination" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="agra">Agra</SelectItem>
                          <SelectItem value="kerala">Kerala</SelectItem>
                          <SelectItem value="rajasthan">Rajasthan</SelectItem>
                          <SelectItem value="goa">Goa</SelectItem>
                          <SelectItem value="himachal">Himachal Pradesh</SelectItem>
                          <SelectItem value="delhi">New Delhi</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="travelers">Number of Travelers</Label>
                      <Select value={travelers} onValueChange={setTravelers}>
                        <SelectTrigger data-testid="select-travelers">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="1">1 Person</SelectItem>
                          <SelectItem value="2">2 People</SelectItem>
                          <SelectItem value="3">3 People</SelectItem>
                          <SelectItem value="4">4 People</SelectItem>
                          <SelectItem value="5">5+ People</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="days">Number of Days</Label>
                      <Input
                        id="days"
                        type="number"
                        placeholder="e.g., 7"
                        value={days}
                        onChange={(e) => setDays(e.target.value)}
                        min="1"
                        max="30"
                        data-testid="input-days"
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="budget">Total Budget (₹)</Label>
                      <Input
                        id="budget"
                        type="number"
                        placeholder="e.g., 50000"
                        value={budget}
                        onChange={(e) => setBudget(e.target.value)}
                        min="1000"
                        data-testid="input-budget"
                      />
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="travel-style">Travel Style</Label>
                    <Select value={travelStyle} onValueChange={setTravelStyle}>
                      <SelectTrigger data-testid="select-travel-style">
                        <SelectValue placeholder="Choose your travel style" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="budget">Budget (Hostels, local transport)</SelectItem>
                        <SelectItem value="mid">Mid-range (Hotels, mix of transport)</SelectItem>
                        <SelectItem value="luxury">Luxury (Premium hotels, private transport)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <Button type="submit" className="w-full" size="lg" data-testid="button-calculate-budget">
                    <Calculator className="h-4 w-4 mr-2" />
                    Calculate Budget Breakdown
                  </Button>
                </form>
              </CardContent>
            </Card>

            {/* Budget Results */}
            <div className="space-y-6">
              {breakdown ? (
                <>
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-center">Budget Breakdown</CardTitle>
                      <CardDescription className="text-center">
                        For {travelers} traveler(s) • {days} days • {destination}
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="text-center mb-6">
                        <div className="text-3xl font-bold text-primary">
                          {formatCurrency(breakdown.total)}
                        </div>
                        <div className="text-muted-foreground">Total Budget</div>
                      </div>
                      
                      <Separator className="mb-6" />
                      
                      <div className="space-y-4">
                        {budgetCategories.map(({ key, label, icon: Icon, color }) => {
                          const amount = breakdown[key as keyof BudgetBreakdown] as number
                          const percentage = (amount / breakdown.total) * 100
                          
                          return (
                            <div key={key} className="flex items-center justify-between">
                              <div className="flex items-center gap-3">
                                <Icon className={`h-5 w-5 ${color}`} />
                                <span className="font-medium">{label}</span>
                              </div>
                              <div className="text-right">
                                <div className="font-semibold">{formatCurrency(amount)}</div>
                                <div className="text-sm text-muted-foreground">
                                  {percentage.toFixed(0)}%
                                </div>
                              </div>
                            </div>
                          )
                        })}
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader>
                      <CardTitle>Daily Budget</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-accent">
                          {formatCurrency(breakdown.total / parseInt(days))}
                        </div>
                        <div className="text-muted-foreground">Per day for all travelers</div>
                      </div>
                      
                      <Separator className="my-4" />
                      
                      <div className="text-center">
                        <div className="text-xl font-semibold">
                          {formatCurrency(breakdown.total / (parseInt(days) * parseInt(travelers)))}
                        </div>
                        <div className="text-muted-foreground">Per person per day</div>
                      </div>
                    </CardContent>
                  </Card>
                </>
              ) : (
                <Card>
                  <CardContent className="flex flex-col items-center justify-center py-12">
                    <Calculator className="h-16 w-16 text-muted-foreground mb-4" />
                    <h3 className="text-lg font-semibold mb-2">Ready to Plan?</h3>
                    <p className="text-muted-foreground text-center">
                      Fill in your trip details to get a personalized budget breakdown
                    </p>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}