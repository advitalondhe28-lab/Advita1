import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, decimal, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const destinations = pgTable("destinations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  city: text("city").notNull(),
  state: text("state").notNull(),
  country: text("country").notNull().default("India"),
  latitude: decimal("latitude", { precision: 10, scale: 8 }).notNull(),
  longitude: decimal("longitude", { precision: 11, scale: 8 }).notNull(),
  description: text("description").notNull(),
  heroImage: text("hero_image").notNull(),
  categories: text("categories").array().notNull(),
  highlights: text("highlights").array().notNull(),
  officialUrl: text("official_url"),
  bestTimeToVisit: text("best_time_to_visit"),
  entryFee: text("entry_fee"),
});

export const hotels = pgTable("hotels", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  destinationId: varchar("destination_id").references(() => destinations.id).notNull(),
  address: text("address").notNull(),
  city: text("city").notNull(),
  state: text("state").notNull(),
  latitude: decimal("latitude", { precision: 10, scale: 8 }),
  longitude: decimal("longitude", { precision: 11, scale: 8 }),
  starRating: integer("star_rating"),
  contactPhone: text("contact_phone"),
  website: text("website"),
  amenities: text("amenities").array().notNull(),
  priceRange: text("price_range"),
  images: text("images").array().notNull(),
  description: text("description"),
});

export const bookings = pgTable("bookings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  itemType: text("item_type").notNull(), // 'hotel' | 'destination'
  itemId: varchar("item_id").notNull(),
  checkIn: timestamp("check_in").notNull(),
  checkOut: timestamp("check_out").notNull(),
  guests: integer("guests").notNull(),
  totalAmount: decimal("total_amount", { precision: 10, scale: 2 }),
  status: text("status").notNull().default("confirmed"), // 'confirmed' | 'cancelled' | 'pending'
  createdAt: timestamp("created_at").defaultNow(),
});

export const costProfiles = pgTable("cost_profiles", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  destinationId: varchar("destination_id").references(() => destinations.id).notNull(),
  budgetType: text("budget_type").notNull(), // 'budget' | 'mid' | 'luxury'
  accommodationPerNight: decimal("accommodation_per_night", { precision: 8, scale: 2 }).notNull(),
  foodPerDay: decimal("food_per_day", { precision: 8, scale: 2 }).notNull(),
  transportPerDay: decimal("transport_per_day", { precision: 8, scale: 2 }).notNull(),
  activitiesPerDay: decimal("activities_per_day", { precision: 8, scale: 2 }).notNull(),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

export const insertDestinationSchema = createInsertSchema(destinations).omit({
  id: true,
});

export const insertHotelSchema = createInsertSchema(hotels).omit({
  id: true,
});

export const insertBookingSchema = createInsertSchema(bookings).omit({
  id: true,
  createdAt: true,
});

export const insertCostProfileSchema = createInsertSchema(costProfiles).omit({
  id: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertDestination = z.infer<typeof insertDestinationSchema>;
export type Destination = typeof destinations.$inferSelect;

export type InsertHotel = z.infer<typeof insertHotelSchema>;
export type Hotel = typeof hotels.$inferSelect;

export type InsertBooking = z.infer<typeof insertBookingSchema>;
export type Booking = typeof bookings.$inferSelect;

export type InsertCostProfile = z.infer<typeof insertCostProfileSchema>;
export type CostProfile = typeof costProfiles.$inferSelect;
