import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Calendar, MapPin, Users, Phone, Mail, CheckCircle, Clock, AlertCircle } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface Booking {
  id: string
  type: "hotel" | "restaurant" | "destination"
  name: string
  location: string
  date: string
  guests: number
  status: "confirmed" | "pending" | "cancelled"
  totalAmount: number
}

export default function Bookings() {
  const [showBookingForm, setShowBookingForm] = useState(false)
  const [bookingType, setBookingType] = useState("")
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    guests: "1",
    checkIn: "",
    checkOut: "",
    specialRequests: ""
  })
  const { toast } = useToast()

  // TODO: Remove mock data - this will be replaced with real API data
  const bookings: Booking[] = [
    {
      id: "book-001",
      type: "hotel",
      name: "The Oberoi Amarvilas",
      location: "Agra, Uttar Pradesh",
      date: "2024-12-15 to 2024-12-18",
      guests: 2,
      status: "confirmed",
      totalAmount: 75000
    },
    {
      id: "book-002",
      type: "restaurant",
      name: "Peshawri",
      location: "Agra, Uttar Pradesh",
      date: "2024-12-16 at 7:00 PM",
      guests: 2,
      status: "confirmed",
      totalAmount: 5000
    },
    {
      id: "book-003",
      type: "hotel",
      name: "Kumarakom Lake Resort",
      location: "Kumarakom, Kerala",
      date: "2024-12-25 to 2024-12-28",
      guests: 4,
      status: "pending",
      totalAmount: 54000
    }
  ]

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    
    console.log("Booking submitted:", { bookingType, ...formData })
    
    // TODO: Replace with real booking API call
    toast({
      title: "Booking Confirmed!",
      description: "Your booking request has been submitted successfully. You will receive a confirmation email shortly.",
    })
    
    setShowBookingForm(false)
    setFormData({
      name: "",
      email: "",
      phone: "",
      guests: "1",
      checkIn: "",
      checkOut: "",
      specialRequests: ""
    })
    setBookingType("")
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "confirmed":
        return <CheckCircle className="h-4 w-4 text-green-500" />
      case "pending":
        return <Clock className="h-4 w-4 text-yellow-500" />
      case "cancelled":
        return <AlertCircle className="h-4 w-4 text-red-500" />
      default:
        return null
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "confirmed":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
      case "pending":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300"
      case "cancelled":
        return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300"
    }
  }

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(amount)
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-primary text-primary-foreground py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
              <h1 className="text-4xl md:text-5xl font-bold mb-4">My Bookings</h1>
              <p className="text-lg text-primary-foreground/90">
                Manage your hotel and restaurant reservations
              </p>
            </div>
            <Button 
              onClick={() => setShowBookingForm(true)}
              variant="secondary"
              size="lg"
              data-testid="button-new-booking"
            >
              New Booking
            </Button>
          </div>
        </div>
      </div>

      <div className="py-8">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Booking Form Modal */}
          {showBookingForm && (
            <Card className="mb-8">
              <CardHeader>
                <CardTitle>New Booking</CardTitle>
                <CardDescription>
                  Fill in the details to make a new reservation
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleFormSubmit} className="space-y-6">
                  <div className="space-y-2">
                    <Label htmlFor="booking-type">Booking Type</Label>
                    <Select value={bookingType} onValueChange={setBookingType}>
                      <SelectTrigger data-testid="select-booking-type">
                        <SelectValue placeholder="Choose booking type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="hotel">Hotel Booking</SelectItem>
                        <SelectItem value="restaurant">Restaurant Reservation</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="name">Full Name</Label>
                      <Input
                        id="name"
                        value={formData.name}
                        onChange={(e) => setFormData({...formData, name: e.target.value})}
                        placeholder="Enter your full name"
                        required
                        data-testid="input-booking-name"
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="email">Email</Label>
                      <Input
                        id="email"
                        type="email"
                        value={formData.email}
                        onChange={(e) => setFormData({...formData, email: e.target.value})}
                        placeholder="Enter your email"
                        required
                        data-testid="input-booking-email"
                      />
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="phone">Phone Number</Label>
                      <Input
                        id="phone"
                        type="tel"
                        value={formData.phone}
                        onChange={(e) => setFormData({...formData, phone: e.target.value})}
                        placeholder="Enter your phone number"
                        required
                        data-testid="input-booking-phone"
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="guests">Number of Guests</Label>
                      <Select value={formData.guests} onValueChange={(value) => setFormData({...formData, guests: value})}>
                        <SelectTrigger data-testid="select-booking-guests">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="1">1 Guest</SelectItem>
                          <SelectItem value="2">2 Guests</SelectItem>
                          <SelectItem value="3">3 Guests</SelectItem>
                          <SelectItem value="4">4 Guests</SelectItem>
                          <SelectItem value="5">5+ Guests</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="check-in">
                        {bookingType === "restaurant" ? "Reservation Date" : "Check-in Date"}
                      </Label>
                      <Input
                        id="check-in"
                        type="date"
                        value={formData.checkIn}
                        onChange={(e) => setFormData({...formData, checkIn: e.target.value})}
                        required
                        data-testid="input-booking-checkin"
                      />
                    </div>
                    
                    {bookingType === "hotel" && (
                      <div className="space-y-2">
                        <Label htmlFor="check-out">Check-out Date</Label>
                        <Input
                          id="check-out"
                          type="date"
                          value={formData.checkOut}
                          onChange={(e) => setFormData({...formData, checkOut: e.target.value})}
                          required
                          data-testid="input-booking-checkout"
                        />
                      </div>
                    )}
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="special-requests">Special Requests (Optional)</Label>
                    <Textarea
                      id="special-requests"
                      value={formData.specialRequests}
                      onChange={(e) => setFormData({...formData, specialRequests: e.target.value})}
                      placeholder="Any special requirements or requests..."
                      data-testid="textarea-booking-requests"
                    />
                  </div>
                  
                  <div className="flex gap-4">
                    <Button type="submit" className="flex-1" data-testid="button-submit-booking">
                      Submit Booking
                    </Button>
                    <Button 
                      type="button" 
                      variant="outline" 
                      onClick={() => setShowBookingForm(false)}
                      data-testid="button-cancel-booking"
                    >
                      Cancel
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          )}

          {/* Bookings List */}
          <div className="space-y-6">
            <h2 className="text-2xl font-bold text-foreground">Your Bookings</h2>
            
            {bookings.length === 0 ? (
              <Card>
                <CardContent className="flex flex-col items-center justify-center py-12">
                  <Calendar className="h-16 w-16 text-muted-foreground mb-4" />
                  <h3 className="text-lg font-semibold mb-2">No Bookings Yet</h3>
                  <p className="text-muted-foreground text-center mb-4">
                    You haven't made any bookings yet. Start planning your trip!
                  </p>
                  <Button onClick={() => setShowBookingForm(true)}>
                    Make Your First Booking
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-1 gap-6">
                {bookings.map((booking) => (
                  <Card key={booking.id} className="hover-elevate" data-testid={`card-booking-${booking.id}`}>
                    <CardHeader>
                      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                        <div>
                          <CardTitle className="flex items-center gap-2">
                            {booking.name}
                            <Badge className={getStatusColor(booking.status)}>
                              {getStatusIcon(booking.status)}
                              <span className="ml-1 capitalize">{booking.status}</span>
                            </Badge>
                          </CardTitle>
                          <CardDescription className="flex items-center gap-1 mt-1">
                            <MapPin className="h-4 w-4" />
                            {booking.location}
                          </CardDescription>
                        </div>
                        <div className="text-right">
                          <div className="text-2xl font-bold text-primary">
                            {formatCurrency(booking.totalAmount)}
                          </div>
                          <div className="text-sm text-muted-foreground">Total Amount</div>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                        <div className="flex items-center gap-2">
                          <Calendar className="h-4 w-4 text-muted-foreground" />
                          <div>
                            <div className="text-sm font-medium">Date</div>
                            <div className="text-sm text-muted-foreground">{booking.date}</div>
                          </div>
                        </div>
                        
                        <div className="flex items-center gap-2">
                          <Users className="h-4 w-4 text-muted-foreground" />
                          <div>
                            <div className="text-sm font-medium">Guests</div>
                            <div className="text-sm text-muted-foreground">{booking.guests} people</div>
                          </div>
                        </div>
                        
                        <div className="flex items-center gap-2">
                          <Badge variant="outline">
                            {booking.type === "hotel" ? "Hotel" : "Restaurant"}
                          </Badge>
                        </div>
                      </div>
                      
                      <div className="flex gap-2 mt-4">
                        <Button variant="outline" size="sm" data-testid={`button-view-${booking.id}`}>
                          View Details
                        </Button>
                        {booking.status === "confirmed" && (
                          <Button variant="outline" size="sm" data-testid={`button-modify-${booking.id}`}>
                            Modify Booking
                          </Button>
                        )}
                        {booking.status === "pending" && (
                          <Button variant="outline" size="sm" data-testid={`button-cancel-${booking.id}`}>
                            Cancel Booking
                          </Button>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}