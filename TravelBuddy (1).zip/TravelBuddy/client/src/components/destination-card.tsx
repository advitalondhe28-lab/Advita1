import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { MapPin, Clock, Star } from "lucide-react"

interface DestinationCardProps {
  id: string
  name: string
  image: string
  description: string
  location: string
  bestTime: string
  rating: number
  reviewCount: number
  featured?: boolean
  onExplore?: (id: string) => void
}

export function DestinationCard({
  id,
  name,
  image,
  description,
  location,
  bestTime,
  rating,
  reviewCount,
  featured = false,
  onExplore
}: DestinationCardProps) {
  return (
    <Card className="hover-elevate group cursor-pointer overflow-hidden" data-testid={`card-destination-${id}`}>
      <div className="relative">
        <img
          src={image}
          alt={name}
          className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
        />
        {featured && (
          <Badge className="absolute top-2 right-2 bg-chart-3 text-white">
            Featured
          </Badge>
        )}
        <div className="absolute bottom-2 left-2 flex items-center space-x-1 bg-black/50 text-white px-2 py-1 rounded">
          <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
          <span className="text-sm font-medium">{rating}</span>
          <span className="text-sm">({reviewCount})</span>
        </div>
      </div>
      
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center justify-between">
          <span>{name}</span>
        </CardTitle>
        <CardDescription className="flex items-center text-muted-foreground">
          <MapPin className="h-4 w-4 mr-1" />
          {location}
        </CardDescription>
      </CardHeader>
      
      <CardContent className="pt-0">
        <p className="text-sm text-muted-foreground mb-3 line-clamp-2">
          {description}
        </p>
        
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center text-sm text-muted-foreground">
            <Clock className="h-4 w-4 mr-1" />
            Best time: {bestTime}
          </div>
        </div>
        
        <Button 
          className="w-full" 
          onClick={() => onExplore?.(id)}
          data-testid={`button-explore-${id}`}
        >
          Explore Destination
        </Button>
      </CardContent>
    </Card>
  )
}