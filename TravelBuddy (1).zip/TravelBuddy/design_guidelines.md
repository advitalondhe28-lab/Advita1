# Smart Tourism Web Application Design Guidelines

## Design Approach: Reference-Based (Travel Industry Leaders)
Drawing inspiration from **Airbnb** and **Booking.com** for their warm, welcoming aesthetics and intuitive navigation patterns that make travel planning feel approachable and exciting.

## Core Design Elements

### Color Palette
**Primary Colors:**
- Deep Ocean Blue: 220 85% 25% (headers, navigation)
- Warm Teal: 180 60% 45% (accent elements)
- Sunset Orange: 25 90% 60% (CTAs, highlights)

**Supporting Colors:**
- Forest Green: 140 40% 35% (success states, nature elements)
- Warm Gray: 30 8% 85% (backgrounds, cards)
- Pure White: 0 0% 100% (text backgrounds)

### Typography
- **Primary Font:** Inter (Google Fonts) - clean, modern readability
- **Display Font:** Poppins (Google Fonts) - friendly headlines
- **Hierarchy:** H1: 2.5rem/bold, H2: 2rem/semibold, Body: 1rem/regular

### Layout System
**Spacing Units:** Consistent use of Tailwind units 2, 4, 6, 8, 12, 16
- Tight spacing: p-2, m-2 (buttons, small elements)
- Standard spacing: p-4, gap-4 (cards, form fields)
- Section spacing: py-8, my-12 (page sections)
- Container spacing: px-6, max-w-6xl (page containers)

### Component Library

**Navigation:**
- Clean horizontal navbar with warm teal background
- Prominent search bar in center
- Mobile: Hamburger menu with slide-out drawer

**Cards:**
- Destination/hotel cards with subtle shadows and rounded corners
- Hover effects with gentle elevation increase
- High-quality imagery with overlay text

**Forms:**
- Input fields with soft borders and focus states in sunset orange
- Large, accessible buttons with warm color gradients
- Clear visual hierarchy with proper spacing

**Data Displays:**
- Clean pricing tables with highlighted recommended options
- Rating systems using warm star colors
- Progress indicators for budget planning steps

### Visual Treatment

**Gradients:**
- Hero sections: Sunset orange to warm teal gradients
- Button gradients: Deep ocean blue to warm teal
- Background overlays: Subtle warm gray gradients

**Background Treatments:**
- Light, airy backgrounds with subtle texture
- Warm white cards on soft gray backgrounds
- Strategic use of full-width colored sections

## Images
**Hero Image:** Large, inspiring travel destination photo spanning full viewport width with overlay text and search functionality

**Content Images:**
- High-quality destination photos (landscapes, landmarks)
- Hotel and restaurant imagery with consistent aspect ratios
- Cultural and activity photos showcasing local experiences
- Food photography with warm, appetizing lighting

**Image Placement:**
- Hero: Full-width banner on homepage
- Destination cards: Square thumbnails with 16:9 ratio
- Detail pages: Gallery layouts with main hero image
- Background elements: Subtle travel-themed patterns

## User Experience Principles
- **Warm & Welcoming:** Colors and imagery should evoke excitement about travel
- **Clear Information Hierarchy:** Essential travel details prominently displayed
- **Intuitive Navigation:** Logical flow from search to booking
- **Trust Building:** Clean design with clear pricing and ratings
- **Mobile-First:** Seamless experience across all devices

The design should feel like a trusted travel companion - professional yet approachable, informative yet inspiring.